
#### Data reconstruction ####

getData <- function(data,order,nTrain,nTest) {
  
  newData=list()
  nData <- nrow(data)
  col=ncol(data)
  rowNum <- nData - order
  colNum <- order*col + 1
  
  matrix <- matrix(NA, nrow = rowNum, ncol = colNum)
  for(i in 1:rowNum) {
    matrix[i, ] = data[i:(order + i)]
  }
  x.fit=matrix[1:(nTrain-order),-(order+1)]
  y.fit=matrix[1:(nTrain-order),(order+1)]
  x.for=matrix[-1:-(nTrain-order),-(order+1)]
  y.real=matrix[-1:-(nTrain-order),(order+1)]
  newData[["x.fit"]]=x.fit
  newData[["y.fit"]]=y.fit
  newData[["x.for"]]=x.for
  newData[["y.real"]]=y.real
  return(newData)
}