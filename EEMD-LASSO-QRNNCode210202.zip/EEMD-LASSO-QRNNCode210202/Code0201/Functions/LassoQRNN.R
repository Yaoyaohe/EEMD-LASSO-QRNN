
#### Lasso + QRNN ####
#' Lasso: Lasso regression for variables select 
#' QRNN: Quantile Regression Neural Network for prediction

library('lars')
LassoQRNN <- function(data,nInput,nTrain,nTest,taus,nh,np,Trace=T){
  
  Max_data=max(data)
  Min_data=min(data)
  data=(data-Min_data)/(Max_data-Min_data)
  data = matrix(data, ncol = 1)
  nData = nrow(data)
  newData=getData(data,nInput,nTrain,nTest)
  x.fit=as.matrix(newData$x.fit)
  y.fit=as.matrix(newData$y.fit)
  x.for=as.matrix(newData$x.for)
  
  #result=list()
  
  # Lasso
  la<-lars(x.fit,y.fit,type="lasso")
  set.seed(100)
  CV.lasso<-cv.lars(x.fit,y.fit,K=10,plot.it = F)
  best<-CV.lasso$index[which.min(CV.lasso$cv)]
  coef.lasso<-coef.lars(la,mode='fraction',s=best)
  co=which(coef.lasso!=0)
  co_l=length(co)
  x.fit=as.matrix(x.fit[,c(co)])
  x.for=as.matrix(x.for[,c(co)])
  
  #QRNN
  
  predMat = matrix(0,nTest,n_tau)
  for(t in 1:length(taus)){
    fit = qrnn.fit(x.fit, y.fit, n.hidden=nh, tau=taus[t], iter.max=1000,n.trials=1, penalty=np,trace = F)
    y.for=qrnn.predict(x.for, fit)
    predMat[,t]=y.for
    if(Trace==T){
      cat("quantile",taus[t],"has finished\n")
    }
  }
  predValue = predMat*(Max_data-Min_data)+Min_data
  
  #result[['s']]=best
  #result[['n']]=co_l
  #result[['predValue']]=predValue
  return(predValue)
}


