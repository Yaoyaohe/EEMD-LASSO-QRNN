#### EEMD-LASSO-QRNN ####
#' Datasets: winter,summer,PA,PB,PC,PD
#' Models: QRNN,LASSO-QRNN,EEMD-QRNN,EEMD-LASSO-QRNN

rm(list=ls())

# Load functions
{
  library(tseries)
  library(Rlibeemd)
  library(scoringRules)
  funPath = paste(getwd(), "/Functions", sep = "")
  fun = list.files(path = funPath, full.names = T, pattern = "*.[R|r]$")
  for(i in 1:length(fun)) {
    source(fun[i])
  }
}  

# establish model
Outputplusplus=list()
for(which_data in 1:6){
  # Read data and set parameters
  # which_data=1, the dataset is winter; 2 is summer; 3 is PA; 4 is PB; 5 is PC; 6 is PD 
  if(which_data==1){
    # winter
    mydata<-read.csv("Data/Spain_1.csv",header =F)
    data=as.numeric(mydata[,2])
    nInput=72 #24*3
    nTrain=576 #24*24
    nTest=168 #24*7 
    h=4 
    p=1
  }
  if(which_data==2){
    # summer
    mydata<-read.csv("Data/Spain_7.csv",header =F)
    data=as.numeric(mydata[,2])
    nInput=72#24*3
    nTrain=576#24*24
    nTest=168#24*7 
    h=2
    p=0
  }
  if(which_data==3){
    # PA
    mydata<-read.csv("Data/pa.csv",header = F)
    data<-mydata[1441:2112,2]#6:1 2113-96*7=1441
    nInput=96*1
    nTrain=96*6
    nTest=96*1 
    h=4
    p=1
  }
  if(which_data==4){
    # PB
    mydata<-read.csv("Data/pb.csv",header = F)
    data<-mydata[1441:2112,2]#6:1 2113-96*7=1441
    nInput=96*1
    nTrain=96*6
    nTest=96*1 
    h=2
    p=0
  }
  if(which_data==5){
    # PC
    mydata<-read.csv("Data/pc.csv",header = F)
    data<-mydata[1441:2112,2]#6:1 2113-96*7=1441
    nInput=96*1
    nTrain=96*6
    nTest=96*1 
    h=4
    p=1
  }
  if(which_data==6){
    # PD
    mydata<-read.csv("Data/pd.csv",header = F)
    data<-mydata[1441:2112,2]#6:1 2113-96*7=1441
    nInput=96*1
    nTrain=96*6
    nTest=96*1 
    h=2
    p=2
  }
  power=data
  nData =length(power)
  maxdata=max(power)
  taus=seq(0.025,0.975,0.05) #confidence interval:95%
  n_tau=length(taus)
  
  #### QRNN & LASSO-QRNN & EEMD-QRNN $ EEMD-LASSO-QRNN ####
  # which_model=1, the model is QRNN; 2, LASSO-QRNN; 3, EEMD-QRNN; 4, EEMD-LASSO-QRNN
  Outputplus=list()
  for(which_model in 1:4){
    set.seed(12345)
    ptm <- proc.time()
    if(which_model==1){
      predVec=QRNN(data,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
    }
    if(which_model==2){
      predVec=LassoQRNN(data,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
    }
    if(which_model==3){
      set.seed(123456)
      eemd=eemd(power)
      imfData=as.data.frame(eemd)
      nimf=ncol(imfData)
      colnames(imfData)=c(paste("IMF",1:(nimf-1)),"residual")
      sum=0
      for(i in 1:nimf){
        tempData=imfData[,i]
        predTemp=QRNN(tempData,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
        sum=sum+predTemp 
        if(i==nimf){
          cat("Residual forecast has finished.\n")
        }else{
          cat("IMF",i,"forecast has finished.\n")
        }
      }
      predVec=sum
    }
    if(which_model==4){
      set.seed(123456)
      eemd=eemd(power)
      imfData=as.data.frame(eemd)
      nimf=ncol(imfData)
      colnames(imfData)=c(paste("IMF",1:(nimf-1)),"residual")
      sum=0
      for(i in 1:nimf){
        tempData=imfData[,i]
        predTemp=LassoQRNN(tempData,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
        sum=sum+predTemp 
        if(i==nimf){
          cat("Residual forecast has finished.\n")
        }else{
          cat("IMF",i,"forecast has finished.\n")
        }
      }
      predVec=sum
    }
    usertime=proc.time() - ptm 
    
    # Kernel density estimation
    crps=NULL
    logs=NULL
    predMat = matrix(0,nTest,5)
    colnames(predMat)=c("Mode","Median","Mean","Min","Max")
    for(k in 1:nTest){
      predTemp=predVec[k,]
      den=density(predTemp,kernel='epanechnikov')
      yy=den[["y"]]
      xx=den[["x"]]
      testObs=power[nData - nTest + k]
      testPred=xx
      crps[k]=crps_sample(testObs,testPred,method = "kde")
      logs[k]=logs_sample(testObs,testPred)
      
      Mode=xx[which.max(yy)]
      Median=median(xx)
      Mean=sum(xx*yy/sum(yy))
      Min=min(xx)
      Max=max(xx)
      pred = cbind(Mode,Median,Mean,Min,Max)
      predMat[k,]=pred
    }
    testPredMat=as.data.frame(predMat)
    testObsMat=power[(nData - nTest + 1):nData]
    error=testPredMat$Mean-testObsMat
    
    predvalue=cbind(testPredMat[,3:5],"Real"=testObsMat,"Error"=error)
    
    # model evaluation 
    errorEval =list()
    errorEval[["point"]][["Mean"]]=Evalution(y.hat=testPredMat$Mean, y=testObsMat, max.y=maxdata, type="point")
    errorEval[["Interval"]]=cbind(Evalution(y=testObsMat,max.y=maxdata, 
                                            y.min=testPredMat$Min,y.max=testPredMat$Max,type="interval"),
                                  "CRPS"=mean(crps),"IS"=mean(logs))
    point=errorEval[["point"]][["Mean"]][,1:3]
    interval=errorEval[["Interval"]][,c(1,2,4)] 
    
    # for output
    Output=list()
    Output[['userime']]=usertime
    Output[['predvalue']]=predvalue
    Output[['crps']]=crps
    Output[['logs']]=logs
    Output[['point']]=point
    Output[['interval']]=interval
    Outputplus[[paste('model',which_model,'')]]=Output
  }
  Outputplusplus[[paste('dataset',which_data,'')]]=Outputplus
}

# write the output for winter
{
  write.csv(Outputplusplus[[1]][[1]][["predvalue"]],file = "Results/winter/pred_winter1.csv")
  write.csv(Outputplusplus[[1]][[2]][["predvalue"]],file = "Results/winter/pred_winter2.csv")
  write.csv(Outputplusplus[[1]][[3]][["predvalue"]],file = "Results/winter/pred_winter3.csv")
  write.csv(Outputplusplus[[1]][[4]][["predvalue"]],file = "Results/winter/pred_winter4.csv")
  
  crps=cbind(Outputplusplus[[1]][[1]][["crps"]],Outputplusplus[[1]][[2]][["crps"]],Outputplusplus[[1]][[3]][["crps"]],Outputplusplus[[1]][[4]][["crps"]])
  point=rbind(Outputplusplus[[1]][[1]][["point"]],Outputplusplus[[1]][[2]][["point"]],Outputplusplus[[1]][[3]][["point"]],Outputplusplus[[1]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[1]][[1]][["interval"]],Outputplusplus[[1]][[2]][["interval"]],Outputplusplus[[1]][[3]][["interval"]],Outputplusplus[[1]][[4]][["interval"]])
  write.csv(crps,file = "Results/winter/crps_winter.csv")
  write.csv(point,file = "Results/winter/point_winter.csv")
  write.csv(inteval,file = "Results/winter/inteval_winter.csv")
}

# write the output for summer
{
  write.csv(Outputplusplus[[2]][[1]][["predvalue"]],file = "Results/summer/pred_summer1.csv")
  write.csv(Outputplusplus[[2]][[2]][["predvalue"]],file = "Results/summer/pred_summer2.csv")
  write.csv(Outputplusplus[[2]][[3]][["predvalue"]],file = "Results/summer/pred_summer3.csv")
  write.csv(Outputplusplus[[2]][[4]][["predvalue"]],file = "Results/summer/pred_summer4.csv")
  
  crps=cbind(Outputplusplus[[2]][[1]][["crps"]],Outputplusplus[[2]][[2]][["crps"]],Outputplusplus[[2]][[3]][["crps"]],Outputplusplus[[2]][[4]][["crps"]])
  point=rbind(Outputplusplus[[2]][[1]][["point"]],Outputplusplus[[2]][[2]][["point"]],Outputplusplus[[2]][[3]][["point"]],Outputplusplus[[2]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[2]][[1]][["interval"]],Outputplusplus[[2]][[2]][["interval"]],Outputplusplus[[2]][[3]][["interval"]],Outputplusplus[[2]][[4]][["interval"]])
  write.csv(crps,file = "Results/summer/crps_summer.csv")
  write.csv(point,file = "Results/summer/point_summer.csv")
  write.csv(inteval,file = "Results/summer/inteval_summer.csv")
}

# write the output for PA
{
  write.csv(Outputplusplus[[3]][[1]][["predvalue"]],file = "Results/pa/pred_pa1.csv")
  write.csv(Outputplusplus[[3]][[2]][["predvalue"]],file = "Results/pa/pred_pa2.csv")
  write.csv(Outputplusplus[[3]][[3]][["predvalue"]],file = "Results/pa/pred_pa3.csv")
  write.csv(Outputplusplus[[3]][[4]][["predvalue"]],file = "Results/pa/pred_pa4.csv")
  
  crps=cbind(Outputplusplus[[3]][[1]][["crps"]],Outputplusplus[[3]][[2]][["crps"]],Outputplusplus[[3]][[3]][["crps"]],Outputplusplus[[3]][[4]][["crps"]])
  point=rbind(Outputplusplus[[3]][[1]][["point"]],Outputplusplus[[3]][[2]][["point"]],Outputplusplus[[3]][[3]][["point"]],Outputplusplus[[3]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[3]][[1]][["interval"]],Outputplusplus[[3]][[2]][["interval"]],Outputplusplus[[3]][[3]][["interval"]],Outputplusplus[[3]][[4]][["interval"]])
  write.csv(crps,file = "Results/pa/crps_pa.csv")
  write.csv(point,file = "Results/pa/point_pa.csv")
  write.csv(inteval,file = "Results/pa/inteval_pa.csv")
}

# write the output for PB
{
  write.csv(Outputplusplus[[4]][[1]][["predvalue"]],file = "Results/pb/pred_pb1.csv")
  write.csv(Outputplusplus[[4]][[2]][["predvalue"]],file = "Results/pb/pred_pb2.csv")
  write.csv(Outputplusplus[[4]][[3]][["predvalue"]],file = "Results/pb/pred_pb3.csv")
  write.csv(Outputplusplus[[4]][[4]][["predvalue"]],file = "Results/pb/pred_pb4.csv")
  
  crps=cbind(Outputplusplus[[4]][[1]][["crps"]],Outputplusplus[[4]][[2]][["crps"]],Outputplusplus[[4]][[3]][["crps"]],Outputplusplus[[4]][[4]][["crps"]])
  point=rbind(Outputplusplus[[4]][[1]][["point"]],Outputplusplus[[4]][[2]][["point"]],Outputplusplus[[4]][[3]][["point"]],Outputplusplus[[4]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[4]][[1]][["interval"]],Outputplusplus[[4]][[2]][["interval"]],Outputplusplus[[4]][[3]][["interval"]],Outputplusplus[[4]][[4]][["interval"]])
  write.csv(crps,file = "Results/pb/crps_pb.csv")
  write.csv(point,file = "Results/pb/point_pb.csv")
  write.csv(inteval,file = "Results/pb/inteval_pb.csv")
}

# write the output for PC
{
  write.csv(Outputplusplus[[5]][[1]][["predvalue"]],file = "Results/pc/pred_pc1.csv")
  write.csv(Outputplusplus[[5]][[2]][["predvalue"]],file = "Results/pc/pred_pc2.csv")
  write.csv(Outputplusplus[[5]][[3]][["predvalue"]],file = "Results/pc/pred_pc3.csv")
  write.csv(Outputplusplus[[5]][[4]][["predvalue"]],file = "Results/pc/pred_pc4.csv")
  
  crps=cbind(Outputplusplus[[5]][[1]][["crps"]],Outputplusplus[[5]][[2]][["crps"]],Outputplusplus[[5]][[3]][["crps"]],Outputplusplus[[5]][[4]][["crps"]])
  point=rbind(Outputplusplus[[5]][[1]][["point"]],Outputplusplus[[5]][[2]][["point"]],Outputplusplus[[5]][[3]][["point"]],Outputplusplus[[5]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[5]][[1]][["interval"]],Outputplusplus[[5]][[2]][["interval"]],Outputplusplus[[5]][[3]][["interval"]],Outputplusplus[[5]][[4]][["interval"]])
  write.csv(crps,file = "Results/pc/crps_pc.csv")
  write.csv(point,file = "Results/pc/point_pc.csv")
  write.csv(inteval,file = "Results/pc/inteval_pc.csv")
}

# write the output for PD
{
  write.csv(Outputplusplus[[6]][[1]][["predvalue"]],file = "Results/pd/pred_pd1.csv")
  write.csv(Outputplusplus[[6]][[2]][["predvalue"]],file = "Results/pd/pred_pd2.csv")
  write.csv(Outputplusplus[[6]][[3]][["predvalue"]],file = "Results/pd/pred_pd3.csv")
  write.csv(Outputplusplus[[6]][[4]][["predvalue"]],file = "Results/pd/pred_pd4.csv")
  
  crps=cbind(Outputplusplus[[6]][[1]][["crps"]],Outputplusplus[[6]][[2]][["crps"]],Outputplusplus[[6]][[3]][["crps"]],Outputplusplus[[6]][[4]][["crps"]])
  point=rbind(Outputplusplus[[6]][[1]][["point"]],Outputplusplus[[6]][[2]][["point"]],Outputplusplus[[6]][[3]][["point"]],Outputplusplus[[6]][[4]][["point"]])
  inteval=rbind(Outputplusplus[[6]][[1]][["interval"]],Outputplusplus[[6]][[2]][["interval"]],Outputplusplus[[6]][[3]][["interval"]],Outputplusplus[[6]][[4]][["interval"]])
  write.csv(crps,file = "Results/pd/crps_pd.csv")
  write.csv(point,file = "Results/pd/point_pd.csv")
  write.csv(inteval,file = "Results/pd/inteval_pd.csv")
}

