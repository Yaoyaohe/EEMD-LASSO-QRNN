
#### Error Evalution ####

Evalution<-function(y.hat, y, max.y, y.min, y.max, type){
  if(type=="point"){
    #ƽ���������
    MAE=mean(abs(y.hat-y))
    #���������
    RMSE=sqrt(mean((y.hat-y)^2))
    #ƽ�����԰ٷֱ����
    MAPE=mean(abs((y.hat-y)/max.y))*100
    
    #׼ȷ��
    R1=(1-(sqrt(mean((y.hat-y)^2/max.y^2))))*100
    #�ϸ���
    RR=1-(y-y.hat)/max.y
    count=sum(RR>=0.75)
    R2=count/length(y)*100
    
    result=cbind(MAE,RMSE,MAPE,R1,R2)
  }
  
  if(type=="interval"){
    count=0
    len=length(y)
    for (k in 1:len) {
      if(y[k]<=y.max[k]&y[k]>=y.min[k]){
        count=count+1
      }
    }
    RR=max(y.max)-min(y.min)
    PINAW=sum(y.max-y.min)/(len*RR)*100
    PICP=count/len*100
    if(PICP>=95){yp=0}else{yp=1}
    CWC=PINAW+yp*exp(-50*(PICP-95))
    result=cbind(PINAW,PICP,CWC)
  }
  return(result)
}
