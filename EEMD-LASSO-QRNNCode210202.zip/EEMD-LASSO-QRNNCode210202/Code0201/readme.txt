 

Short-term power load probability density forecasting based on quantile regression neural network and triangle kernel function, Energy, 2016,114:498-512 

Probability density forecasting of wind power using quantile regression  neural network and kernel density estimation, Energy Conversion and Management, 2018, 164: 374-384

Electricity consumption probability density forecasting method based on LASSO-Quantile Regression Neural Network, Applied Energy, 2019, 233-234: 565-575 

Short-term wind power prediction based on EEMD-LASSO-QRNN model, Applied Soft Computing, 2021 ,105:107288  




####### Data: the raw data of wind power
# Spain_1;Spain_7;pa;pb;pc;pd

####### Functions: the relevant functions used in main procedure
# Evalution: calculate some evaluation indicators
# getData: data normalization and split train/test set
# QRNN: the base forecasting model
# LassoQRNN: the base forecasting model that combines LASSO feature selection and QRNN forecasting model


####### PA,PB,PC,PD,summer,winter
# The six R codes own the same construction, only with different in the raw data

