#### PB ####

# Load functions
{
  rm(list=ls())
  # Library packages
  library(tseries)
  library(Rlibeemd)
  library(scoringRules)
  
  funPath = paste(getwd(), "/Functions", sep = "")
  fun = list.files(path = funPath, full.names = T, pattern = "*.[R|r]$")
  for(i in 1:length(fun)) {
    source(fun[i])
  }
}  

# PB dataset
{
  mydata<-read.csv("Data/pb.csv",header = F)
  data<-mydata[1441:2112,2]#6:1 2113-96*7=1441
  power=data
  nData =length(power)
  maxdata=max(power)
  nInput=96*1
  nTrain=96*6
  nTest=96*1 
  taus=seq(0.025,0.975,0.05) #confidence interval:95%
  n_tau=length(taus)
  h=2
  p=0
}

#### QRNN & LASSO-QRNN####
{
  # Forecast
  set.seed(12345)
  ptm <- proc.time()
  func=1# if func is 1, the forecasting model is QRNN; if the func is 2, that is LassoQRNN
  if(func==1){
    predVec=QRNN(data,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
  }
  if(func==2){
    predVec=LassoQRNN(data,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
    predVec=predVec[["predValue"]]
  }
  
  usertime=proc.time() - ptm 
  
  # Kernel density estimation
  crps=NULL
  logs=NULL
  predMat = matrix(0,nTest,5)
  colnames(predMat)=c("Mode","Median","Mean","Min","Max")
  for(k in 1:nTest){
    predTemp=predVec[k,]
    den=density(predTemp,kernel='epanechnikov')
    yy=den[["y"]]
    xx=den[["x"]]
    testObs=power[nData - nTest + k]
    testPred=xx
    crps[k]=crps_sample(testObs,testPred,method = "kde")
    logs[k]=logs_sample(testObs,testPred)
    
    Mode=xx[which.max(yy)]
    Median=median(xx)
    Mean=sum(xx*yy/sum(yy))
    Min=min(xx)
    Max=max(xx)
    pred = cbind(Mode,Median,Mean,Min,Max)
    predMat[k,]=pred
  }
  testPredMat=as.data.frame(predMat)
  testObsMat=power[(nData - nTest + 1):nData]
  error=testPredMat$Mean-testObsMat
  
  predvalue=cbind(testPredMat[,3:5],"Real"=testObsMat,"Error"=error)
  
  # model evaluation 
  errorEval =list()
  errorEval[["point"]][["Mean"]]=Evalution(y.hat=testPredMat$Mean, y=testObsMat,max.y=maxdata, type="point")
  errorEval[["Interval"]]=cbind(Evalution(y=testObsMat, max.y=maxdata, 
                                          y.min=testPredMat$Min,y.max=testPredMat$Max,type="interval"),
                                "CRPS"=mean(crps),"IS"=mean(logs))
  
  point=errorEval[["point"]][["Mean"]][,1:3] 
  interval=errorEval[["Interval"]][,c(1,2,4)] 
  
  Output=list()
  Output[['usertime']]=usertime
  Output[['predvalue']]=predvalue
  Output[['point']]=point
  Output[['crps']]=crps
  Output[['logs']]=logs
  Output[['interval']]=interval
}

if(func==1){
  Output1=Output
}else{
  Output2=Output
}


#### EEMD-QRNN & EEMD-LASSO-QRNN ####
# Decomposition methods
{
  set.seed(123456)
  eemd=eemd(power)
  imfData=as.data.frame(eemd)
  nimf=ncol(imfData)
  colnames(imfData)=c(paste("IMF",1:(nimf-1)),"residual")
  
  # Forecast
  ptm <- proc.time()
  
  fu=1# if fu=1, the model is QRNN, if fu=2, the model is LassoQRNN
  sum=0
  for(i in 1:nimf){
    
    tempData=imfData[,i]
    if(fu==1){
      predTemp=QRNN(tempData,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
    }
    if(fu==2){
      predTemp=LassoQRNN(tempData,nInput,nTrain,nTest,taus=taus,nh=h,np=p)
      predTemp=predTemp[["predValue"]]  
    }
    sum=sum+predTemp 
    if(i==nimf){
      cat("Residual forecast has finished.\n")
    }else{
      cat("IMF",i,"forecast has finished.\n")
    }
  }
  emd.predVec=sum
  usertime=proc.time() - ptm 
  
  # Density estimation 
  emd.crps=NULL
  emd.logs=NULL
  emd.predMat = matrix(0,nTest,5)
  colnames(emd.predMat)=c("Mode","Median","Mean","Min","Max")
  for(k in 1:nTest){
    predTemp=emd.predVec[k,]
    den=density(predTemp, kernel='epanechnikov')
    yy=den[["y"]]
    xx=den[["x"]]
    testObs=power[nData - nTest + k]
    testPred=xx
    emd.crps[k]=crps_sample(testObs,testPred,method = "kde") 
    emd.logs[k]=logs_sample(testObs,testPred) 
    
    Mode=xx[which.max(yy)]
    Median=median(xx)
    Mean=sum(xx*yy/sum(yy))
    Min=min(xx)
    Max=max(xx)
    pred = cbind(Mode,Median,Mean,Min,Max)
    emd.predMat[k,]=pred
  }
  
  testPredMat=as.data.frame(emd.predMat)
  testObsMat=power[(nData - nTest + 1):nData]
  error=testPredMat$Mean-testObsMat
  predvalue=cbind(testPredMat[,3:5],"Real"=testObsMat,"Error"=error)
  
  # Model Evaluation 
  emd.errorEval =list()
  emd.errorEval[["point"]][["Mean"]]=Evalution(y.hat=testPredMat$Mean, y=testObsMat, max.y = maxdata, type="point")
  emd.errorEval[["Interval"]]=cbind(Evalution(y=testObsMat, max.y = maxdata,
                                              y.min=testPredMat$Min,y.max=testPredMat$Max,type="interval"),
                                    "CRPS"=mean(emd.crps),"IS"=mean(emd.logs))
  point=emd.errorEval[["point"]][["Mean"]][,1:3] 
  interval=emd.errorEval[["Interval"]][,c(1,2,4)] 
  
  Output=list()
  Output[['usertime']]=usertime
  Output[['predvalue']]=predvalue
  Output[['point']]=point
  Output[['crps']]=emd.crps
  Output[['logs']]=emd.logs
  Output[['interval']]=interval
}

if(fu==1){
  Output3=Output 
}else{
  Output4=Output
}

# write data
# 1:QRNN 2:LASSO-QRNN 3:EEMD-QRNN 4:EEMD-LASSO-QRNN

write.csv(Output1[["predvalue"]],file = "pred_pb1.csv")
write.csv(Output2[["predvalue"]],file = "pred_pb2.csv")
write.csv(Output3[["predvalue"]],file = "pred_pb3.csv")
write.csv(Output4[["predvalue"]],file = "pred_pb4.csv")

crps=cbind(Output1[["crps"]],Output2[["crps"]],Output3[["crps"]],Output4[["crps"]])
point=rbind(Output1[["point"]],Output2[["point"]],Output3[["point"]],Output4[["point"]])
inteval=rbind(Output1[["interval"]],Output2[["interval"]],Output3[["interval"]],Output4[["interval"]])
write.csv(crps,file = "crps_pb.csv")
write.csv(point,file = "point_pb.csv")
write.csv(inteval,file = "inteval_pb.csv")



