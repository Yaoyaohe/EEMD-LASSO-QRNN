
#### QRNN ####
#' QRNN: Quantile Regression Neural Network for prediction

library('qrnn')
QRNN <- function(data,nInput,nTrain,nTest,taus,nh,np,Trace=T){
  
  Max_data=max(data)
  Min_data=min(data)
  data=(data-Min_data)/(Max_data-Min_data)
  data = as.matrix(data)
  col=ncol(data)
  nData = nrow(data)
  newData=getData(data,nInput,nTrain,nTest)
  x.fit=as.matrix(newData$x.fit)
  y.fit=as.matrix(newData$y.fit)
  x.for=as.matrix(newData$x.for)
  
  #QRNN
  predMat = matrix(0,nTest,n_tau)
  for(t in 1:length(taus)){
    fit = qrnn.fit(x.fit, y.fit, n.hidden=nh, tau=taus[t], iter.max=1000,n.trials=1, penalty=np,trace = F)
    y.for=qrnn.predict(x.for, fit)
    predMat[,t]=y.for
    if(Trace==T){
      cat("quantile",taus[t],"has finished\n")
    }
  }
  predValue = predMat*(Max_data-Min_data)+Min_data
  return(predValue)
}


